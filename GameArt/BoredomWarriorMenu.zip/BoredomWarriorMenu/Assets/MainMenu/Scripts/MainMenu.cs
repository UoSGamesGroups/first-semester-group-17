﻿//// <Summary>
//// Main Menu
//// Attached to Main Menu
//// </Summary>

using UnityEngine;
using System.Collections;

public class MainMenu : MonoBehaviour {

    public Texture backgroundTexture;

    public float guiPlacementY;

    void OnGUI()
    {

    //// Displays Background Texture
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), backgroundTexture);

        //// Displays Buttons

        if (GUI.Button(new Rect(Screen.width * .25f, Screen.height * .25f, Screen.width * .5f, Screen.height * .1f), "Play Game")) {
            print("Clicked Play Game");
        
        }

        if (GUI.Button(new Rect(Screen.width * .25f, Screen.height * .75f, Screen.width * .5f, Screen.height * .1f), "Options")) {
            print("Clicked Options");

        }
    }

}
